# Listing_8-2.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version: $version: be6c6824f35f $  ----------------------------

# Doing something different each time through the loop

for looper in [1, 2, 3, 4, 5]:
    print looper
