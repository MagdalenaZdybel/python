# Listing_5-1.py
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version: $version: be6c6824f35f $  ----------------------------

# Getting a string from the user

print "Enter your name: "
somebody = raw_input()
print "Hi", somebody, "how are you today?"
