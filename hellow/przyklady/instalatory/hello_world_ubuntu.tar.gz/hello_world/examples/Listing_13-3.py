# Listing_13-3
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version: $version: be6c6824f35f $  ----------------------------

# Function with two arguments

def printMyAddress(someName, houseNum):    
    print someName                         
    print houseNum,        # Comma makes houseNum and street print on the same line       
    print "Main Street"           
    print "Ottawa, Ontario, Canada"          
    print "K2M 2E9"                   
    print                             
    
printMyAddress("Carter Sande", "45")   # pass 2 arguments to the function
printMyAddress("Jack Black", "64")     
printMyAddress("Tom Green", "22")      
printMyAddress("Todd White", "36")     
