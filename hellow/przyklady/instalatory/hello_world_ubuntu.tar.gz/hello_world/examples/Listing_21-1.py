# Listing_21-1.py
# Copyright Warren & Csrter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version: $version: be6c6824f35f $  ----------------------------

# A program to print squares and cubes

print "Number \tSquare \tCube"
for i in range (1, 11):
    print i, '\t', i**2, '\t', i**3
