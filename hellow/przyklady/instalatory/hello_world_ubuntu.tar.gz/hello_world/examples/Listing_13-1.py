# Listing_13-1
# Copyright Warren & Carter Sande, 2013
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version: $version: be6c6824f35f $  ----------------------------

# Creating and using a function

# Define a function
def printMyAddress():                 
    print "Warren Sande"              
    print "123 Main Street"           
    print "Ottawa, Ontario, Canada"           
    print "K2M 2E9"                   
    print                             
    
# main program starts here - call the function
printMyAddress()                
