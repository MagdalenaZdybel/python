#!/bin/bash
#standard python packages
apt-get install python-numpy python-pygame python-qt4 python-tk

#So uh, where is python anyway?
export sitelib=`python -c "from distutils.sysconfig import get_python_lib; print get_python_lib()"`

echo "Found python site lib at:\n$sitelib"

#easygui
cp easygui/easygui.py $sitelib/easygui.py
cp -R easygui $sitelib/easygui
rm -Rf easygui

